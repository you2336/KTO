def con_game():
    print('this is gameWindow..')

    input('Please enter..\nNext Title..\n')

    return "title"