def con_log():
    print('this is logWindow..')

    input('Please enter..\nNext Title..\n')

    return "title"