def con_setting():
    print('this is settingWindow..')

    input('Please enter..\nNext Title..\n')

    return "title"