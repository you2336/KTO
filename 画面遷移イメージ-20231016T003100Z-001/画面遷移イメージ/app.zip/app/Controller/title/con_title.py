def con_title():
    print('this is titleWindow..')

    while True:
        x = input("""
    next..
    1.game
    2.log
    3.setting\n
    """)
        print(x)
        if x == '1':
            return 'game'
        if x == '2':
            return 'log'
        if x == '3':
            return 'setting'